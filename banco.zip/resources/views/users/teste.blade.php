<?php

$nome = 'lucka';
$sobrenome = 'matoso';
//echo $nome.$sobrenome;
//echo 'luca $sobrenome';
echo "luca $sobrenome";