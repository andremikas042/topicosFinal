<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TransacaoController extends Controller
{
    public function deposito()
    {
        //
    }

    public function saque()
    {
        //
    }

    public function transferenca()
    {
        //
    }
}
